@tool
class_name BgRemover

# Perceptual color distance flood-fill background remover with alpha matting.
# Highly optimized: all pixel loops run on raw PackedByteArray directly, eliminating all get_pixel()/set_pixel() bridge overhead.

const _K: int = 4
const _KMEANS_ITER: int = 12
const _MAT_RADIUS: int = 3

static func remove(image: Image, tolerance: float = 0.18, feather: bool = true) -> Image:
	var img: Image = image.duplicate()
	img.convert(Image.FORMAT_RGBA8)

	var W: int = img.get_width()
	var H: int = img.get_height()
	if W < 2 or H < 2:
		return img

	var bg_centers: Array = _edge_kmeans(img, W, H)

	var removed := PackedByteArray()
	removed.resize(W * H)
	removed.fill(0)

	var raw: PackedByteArray = img.get_data()

	for ci in range(bg_centers.size()):
		var bg: Color = bg_centers[ci]
		_bfs_fill_raw(raw, bg, tolerance, W, H, removed)

	_apply_matting_raw(img, raw, removed, W, H, feather)

	return img

static func _edge_kmeans(img: Image, W: int, H: int) -> Array:
	var samples: Array = []
	var step: int = max(1, min(W, H) / 60)

	for x in range(0, W, step):
		samples.append(img.get_pixel(x, 0))
		samples.append(img.get_pixel(x, H - 1))
	for y in range(0, H, step):
		samples.append(img.get_pixel(0, y))
		samples.append(img.get_pixel(W - 1, y))

	var corners: Array = [
		img.get_pixel(0, 0),
		img.get_pixel(W - 1, 0),
		img.get_pixel(0, H - 1),
		img.get_pixel(W - 1, H - 1)
	]
	for _r in range(8):
		for c in corners:
			samples.append(c)

	if samples.size() == 0:
		return [Color.WHITE]

	var k: int = min(_K, samples.size())
	var centers: Array = []
	for i in range(k):
		var idx: int = (i * samples.size()) / k
		centers.append(samples[idx])

	for _iter in range(_KMEANS_ITER):
		var sums_r: Array = []
		var sums_g: Array = []
		var sums_b: Array = []
		var counts: Array = []
		for i in range(k):
			sums_r.append(0.0)
			sums_g.append(0.0)
			sums_b.append(0.0)
			counts.append(0)

		for sv in samples:
			var s: Color = sv
			var best_ci: int = 0
			var best_d: float = _dist(s, centers[0])
			for ci in range(1, k):
				var d: float = _dist(s, centers[ci])
				if d < best_d:
					best_d = d
					best_ci = ci
			sums_r[best_ci] = sums_r[best_ci] + s.r
			sums_g[best_ci] = sums_g[best_ci] + s.g
			sums_b[best_ci] = sums_b[best_ci] + s.b
			counts[best_ci] = counts[best_ci] + 1

		for ci in range(k):
			var cnt: int = counts[ci]
			if cnt > 0:
				centers[ci] = Color(sums_r[ci] / cnt, sums_g[ci] / cnt, sums_b[ci] / cnt, 1.0)

	return centers

static func _bfs_fill_raw(raw: PackedByteArray, bg: Color, tol: float,
		W: int, H: int, removed: PackedByteArray) -> void:
	var visited := removed.duplicate()

	var queue: Array = []
	var head: int = 0

	var bg_r := bg.r
	var bg_g := bg.g
	var bg_b := bg.b

	for x in range(W):
		_try_seed_raw(queue, visited, raw, x, 0, bg_r, bg_g, bg_b, tol, W, H)
		_try_seed_raw(queue, visited, raw, x, H - 1, bg_r, bg_g, bg_b, tol, W, H)
	for y in range(1, H - 1):
		_try_seed_raw(queue, visited, raw, 0, y, bg_r, bg_g, bg_b, tol, W, H)
		_try_seed_raw(queue, visited, raw, W - 1, y, bg_r, bg_g, bg_b, tol, W, H)

	while head < queue.size():
		var p: Vector2i = queue[head]
		head += 1
		removed[p.y * W + p.x] = 1

		var nx: int = p.x - 1
		if nx >= 0: _try_seed_raw(queue, visited, raw, nx, p.y, bg_r, bg_g, bg_b, tol, W, H)
		nx = p.x + 1
		if nx < W: _try_seed_raw(queue, visited, raw, nx, p.y, bg_r, bg_g, bg_b, tol, W, H)
		var ny: int = p.y - 1
		if ny >= 0: _try_seed_raw(queue, visited, raw, p.x, ny, bg_r, bg_g, bg_b, tol, W, H)
		ny = p.y + 1
		if ny < H: _try_seed_raw(queue, visited, raw, p.x, ny, bg_r, bg_g, bg_b, tol, W, H)

static func _try_seed_raw(queue: Array, visited: PackedByteArray, raw: PackedByteArray,
		x: int, y: int, bg_r: float, bg_g: float, bg_b: float, tol: float, W: int, H: int) -> void:
	var idx: int = y * W + x
	if visited[idx] != 0:
		return
	visited[idx] = 1
	var r_idx := idx * 4
	var a: int = raw[r_idx + 3]
	if a < 13: # 0.05 * 255 = 12.75
		queue.append(Vector2i(x, y))
	else:
		var r: int = raw[r_idx]
		var g: int = raw[r_idx + 1]
		var b: int = raw[r_idx + 2]
		if _dist_raw(r, g, b, bg_r, bg_g, bg_b) <= tol:
			queue.append(Vector2i(x, y))

static func _apply_matting_raw(img: Image, raw: PackedByteArray, removed: PackedByteArray,
		W: int, H: int, feather: bool) -> void:
	for y in range(H):
		var row_base := y * W
		for x in range(W):
			if removed[row_base + x] != 0:
				var r_idx := (row_base + x) * 4
				raw[r_idx + 3] = 0

	if not feather:
		img.create_from_data(W, H, false, Image.FORMAT_RGBA8, raw)
		return

	var dist_map := PackedFloat32Array()
	dist_map.resize(W * H)
	var BIG: float = float(W + H + 1)

	for y in range(H):
		var row_base := y * W
		for x in range(W):
			var idx := row_base + x
			if raw[idx * 4 + 3] < 3: # 0.01 * 255.0 = 2.55
				dist_map[idx] = 0.0
			else:
				dist_map[idx] = BIG

	# Forward pass
	for y in range(H):
		var row_base := y * W
		for x in range(W):
			var idx := row_base + x
			if dist_map[idx] == 0.0:
				continue
			var best: float = dist_map[idx]
			if x > 0:
				var v: float = dist_map[idx - 1] + 1.0
				if v < best:
					best = v
			if y > 0:
				var v: float = dist_map[idx - W] + 1.0
				if v < best:
					best = v
			dist_map[idx] = best

	# Backward pass
	for y in range(H - 1, -1, -1):
		var row_base := y * W
		for x in range(W - 1, -1, -1):
			var idx := row_base + x
			if dist_map[idx] == 0.0:
				continue
			var best: float = dist_map[idx]
			if x < W - 1:
				var v: float = dist_map[idx + 1] + 1.0
				if v < best:
					best = v
			if y < H - 1:
				var v: float = dist_map[idx + W] + 1.0
				if v < best:
					best = v
			dist_map[idx] = best

	# Apply matting to raw bytes
	var raw_out := raw.duplicate()
	for y in range(H):
		var row_base := y * W
		for x in range(W):
			var idx := row_base + x
			var raw_idx := idx * 4
			var a := raw[raw_idx + 3]
			if a < 3:
				continue
			var d: float = dist_map[idx]
			if d > _MAT_RADIUS:
				continue
			var t: float = d / float(_MAT_RADIUS)
			var smooth_t: float = t * t * (3.0 - 2.0 * t)
			raw_out[raw_idx + 3] = int(a * smooth_t)

	img.create_from_data(W, H, false, Image.FORMAT_RGBA8, raw_out)

static func _dist(a: Color, b: Color) -> float:
	var dr: float = a.r - b.r
	var dg: float = a.g - b.g
	var db: float = a.b - b.b
	return sqrt(dr * dr * 0.299 + dg * dg * 0.587 + db * db * 0.114)

static func _dist_raw(r1: int, g1: int, b1: int, r2: float, g2: float, b2: float) -> float:
	var dr: float = float(r1) / 255.0 - r2
	var dg: float = float(g1) / 255.0 - g2
	var db: float = float(b1) / 255.0 - b2
	return sqrt(dr * dr * 0.299 + dg * dg * 0.587 + db * db * 0.114)

static func magic_wand_erase(image: Image, start_x: int, start_y: int, tolerance: float) -> Image:
	var img: Image = image.duplicate()
	img.convert(Image.FORMAT_RGBA8)

	var W: int = img.get_width()
	var H: int = img.get_height()
	if W < 2 or H < 2:
		return img
	if start_x < 0 or start_y < 0 or start_x >= W or start_y >= H:
		return img
		
	var bg: Color = img.get_pixel(start_x, start_y)
	if bg.a < 0.05:
		return img

	var removed := PackedByteArray()
	removed.resize(W * H)
	removed.fill(0)
	
	var visited := PackedByteArray()
	visited.resize(W * H)
	visited.fill(0)

	var queue: Array = []
	var head: int = 0
	
	var raw := img.get_data()
	var bg_r := bg.r
	var bg_g := bg.g
	var bg_b := bg.b

	_try_seed_raw(queue, visited, raw, start_x, start_y, bg_r, bg_g, bg_b, tolerance, W, H)

	while head < queue.size():
		var p: Vector2i = queue[head]
		head += 1
		removed[p.y * W + p.x] = 1

		var nx: int = p.x - 1
		if nx >= 0: _try_seed_raw(queue, visited, raw, nx, p.y, bg_r, bg_g, bg_b, tolerance, W, H)
		nx = p.x + 1
		if nx < W: _try_seed_raw(queue, visited, raw, nx, p.y, bg_r, bg_g, bg_b, tolerance, W, H)
		var ny: int = p.y - 1
		if ny >= 0: _try_seed_raw(queue, visited, raw, p.x, ny, bg_r, bg_g, bg_b, tolerance, W, H)
		ny = p.y + 1
		if ny < H: _try_seed_raw(queue, visited, raw, p.x, ny, bg_r, bg_g, bg_b, tolerance, W, H)

	for y in range(H):
		var row_base := y * W
		for x in range(W):
			if removed[row_base + x] != 0:
				raw[(row_base + x) * 4 + 3] = 0

	img.create_from_data(W, H, false, Image.FORMAT_RGBA8, raw)
	return img

static func brush_erase(image: Image, center_x: int, center_y: int, radius: float, is_square: bool = false) -> Image:
	image.convert(Image.FORMAT_RGBA8)
	var W: int = image.get_width()
	var H: int = image.get_height()
	var r_ceil := int(ceil(radius))

	var raw := image.get_data()
	for y in range(max(0, center_y - r_ceil), min(H, center_y + r_ceil + 1)):
		var row_base := y * W
		for x in range(max(0, center_x - r_ceil), min(W, center_x + r_ceil + 1)):
			if is_square:
				raw[(row_base + x) * 4 + 3] = 0
			else:
				var dx := x - center_x
				var dy := y - center_y
				if float(dx*dx + dy*dy) <= radius*radius:
					raw[(row_base + x) * 4 + 3] = 0

	image.create_from_data(W, H, false, Image.FORMAT_RGBA8, raw)
	return image

static func brush_paint(image: Image, center_x: int, center_y: int, radius: float, color: Color, is_square: bool = false) -> Image:
	image.convert(Image.FORMAT_RGBA8)
	var W: int = image.get_width()
	var H: int = image.get_height()
	var r_ceil := int(ceil(radius))

	var raw := image.get_data()
	var c_r := int(color.r * 255.0)
	var c_g := int(color.g * 255.0)
	var c_b := int(color.b * 255.0)
	var c_a := int(color.a * 255.0)

	for y in range(max(0, center_y - r_ceil), min(H, center_y + r_ceil + 1)):
		var row_base := y * W
		for x in range(max(0, center_x - r_ceil), min(W, center_x + r_ceil + 1)):
			var draw_pixel := false
			if is_square:
				draw_pixel = true
			else:
				var dx := x - center_x
				var dy := y - center_y
				if float(dx*dx + dy*dy) <= radius*radius:
					draw_pixel = true
			
			if draw_pixel:
				var r_idx := (row_base + x) * 4
				raw[r_idx] = c_r
				raw[r_idx + 1] = c_g
				raw[r_idx + 2] = c_b
				raw[r_idx + 3] = c_a

	image.create_from_data(W, H, false, Image.FORMAT_RGBA8, raw)
	return image

static func paste_stamp_transformed(
	base_image: Image,
	stamp_image: Image,
	pos: Vector2,
	scale: Vector2,
	rotation: float,
	pivot: Vector2
) -> Image:
	base_image.convert(Image.FORMAT_RGBA8)
	stamp_image.convert(Image.FORMAT_RGBA8)
	
	var dst_w := base_image.get_width()
	var dst_h := base_image.get_height()
	var src_w := stamp_image.get_width()
	var src_h := stamp_image.get_height()
	
	var xform := Transform2D()
	xform = xform.translated(pos)
	xform = xform.rotated(rotation)
	xform = xform.scaled(scale)
	xform = xform.translated(-pivot)
	
	var inv := xform.affine_inverse()
	
	var corners = [
		xform * Vector2(0, 0),
		xform * Vector2(src_w, 0),
		xform * Vector2(0, src_h),
		xform * Vector2(src_w, src_h)
	]
	var min_x = dst_w
	var max_x = 0
	var min_y = dst_h
	var max_y = 0
	for c in corners:
		min_x = min(min_x, int(floor(c.x)))
		max_x = max(max_x, int(ceil(c.x)))
		min_y = min(min_y, int(floor(c.y)))
		max_y = max(max_y, int(ceil(c.y)))
		
	min_x = clamp(min_x, 0, dst_w - 1)
	max_x = clamp(max_x, 0, dst_w - 1)
	min_y = clamp(min_y, 0, dst_h - 1)
	max_y = clamp(max_y, 0, dst_h - 1)
	
	var base_raw := base_image.get_data()
	var stamp_raw := stamp_image.get_data()

	for y in range(min_y, max_y + 1):
		var row_base := y * dst_w
		for x in range(min_x, max_x + 1):
			var src_pos := inv * Vector2(x, y)
			var sx := int(round(src_pos.x))
			var sy := int(round(src_pos.y))
			if sx >= 0 and sx < src_w and sy >= 0 and sy < src_h:
				var s_idx := (sy * src_w + sx) * 4
				var s_a := stamp_raw[s_idx + 3]
				if s_a > 0:
					var b_idx := (row_base + x) * 4
					var s_r := stamp_raw[s_idx]
					var s_g := stamp_raw[s_idx + 1]
					var s_b := stamp_raw[s_idx + 2]
					
					var b_r := base_raw[b_idx]
					var b_g := base_raw[b_idx + 1]
					var b_b := base_raw[b_idx + 2]
					var b_a := base_raw[b_idx + 3]
					
					var src_alpha := float(s_a) / 255.0
					var out_a := s_a + int(float(b_a) * (1.0 - src_alpha))
					if out_a > 0:
						var out_r := int((float(s_r) * s_a + float(b_r) * b_a * (1.0 - src_alpha)) / float(out_a))
						var out_g := int((float(s_g) * s_a + float(b_g) * b_a * (1.0 - src_alpha)) / float(out_a))
						var out_b := int((float(s_b) * s_a + float(b_b) * b_a * (1.0 - src_alpha)) / float(out_a))
						base_raw[b_idx] = clamp(out_r, 0, 255)
						base_raw[b_idx + 1] = clamp(out_g, 0, 255)
						base_raw[b_idx + 2] = clamp(out_b, 0, 255)
						base_raw[b_idx + 3] = clamp(out_a, 0, 255)
					
	base_image.create_from_data(dst_w, dst_h, false, Image.FORMAT_RGBA8, base_raw)
	return base_image

static func magic_wand_recolor(image: Image, start_x: int, start_y: int, new_color: Color, tolerance: float) -> Image:
	var img: Image = image.duplicate()
	img.convert(Image.FORMAT_RGBA8)

	var W: int = img.get_width()
	var H: int = img.get_height()
	if W < 2 or H < 2:
		return img
	if start_x < 0 or start_y < 0 or start_x >= W or start_y >= H:
		return img
		
	var bg: Color = img.get_pixel(start_x, start_y)
	if bg.a < 0.01:
		return img

	var recolored := PackedByteArray()
	recolored.resize(W * H)
	recolored.fill(0)
	
	var visited := PackedByteArray()
	visited.resize(W * H)
	visited.fill(0)

	var queue: Array = []
	var head: int = 0
	
	var raw := img.get_data()
	var bg_r := bg.r
	var bg_g := bg.g
	var bg_b := bg.b

	_try_seed_raw(queue, visited, raw, start_x, start_y, bg_r, bg_g, bg_b, tolerance, W, H)

	while head < queue.size():
		var p: Vector2i = queue[head]
		head += 1
		recolored[p.y * W + p.x] = 1

		var nx: int = p.x - 1
		if nx >= 0: _try_seed_raw(queue, visited, raw, nx, p.y, bg_r, bg_g, bg_b, tolerance, W, H)
		nx = p.x + 1
		if nx < W: _try_seed_raw(queue, visited, raw, nx, p.y, bg_r, bg_g, bg_b, tolerance, W, H)
		var ny: int = p.y - 1
		if ny >= 0: _try_seed_raw(queue, visited, raw, p.x, ny, bg_r, bg_g, bg_b, tolerance, W, H)
		ny = p.y + 1
		if ny < H: _try_seed_raw(queue, visited, raw, p.x, ny, bg_r, bg_g, bg_b, tolerance, W, H)

	var nc_r := int(new_color.r * 255.0)
	var nc_g := int(new_color.g * 255.0)
	var nc_b := int(new_color.b * 255.0)

	for y in range(H):
		var row_base := y * W
		for x in range(W):
			if recolored[row_base + x] != 0:
				var r_idx := (row_base + x) * 4
				raw[r_idx] = nc_r
				raw[r_idx + 1] = nc_g
				raw[r_idx + 2] = nc_b

	img.create_from_data(W, H, false, Image.FORMAT_RGBA8, raw)
	return img

static func paste_stamp(base_image: Image, stamp_image: Image, center_x: int, center_y: int) -> Image:
	base_image.convert(Image.FORMAT_RGBA8)
	stamp_image.convert(Image.FORMAT_RGBA8)
	
	var stamp_w := stamp_image.get_width()
	var stamp_h := stamp_image.get_height()
	
	var dest_x := center_x - stamp_w / 2
	var dest_y := center_y - stamp_h / 2
	
	base_image.blend_rect(stamp_image, Rect2i(0, 0, stamp_w, stamp_h), Vector2i(dest_x, dest_y))
	return base_image
